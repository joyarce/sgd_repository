from django.apps import AppConfig


class PlantillasDocumentosTecnicosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'plantillas_documentos_tecnicos'
