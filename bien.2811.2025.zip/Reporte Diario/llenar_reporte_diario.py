# C:\Users\jonat\Desktop\memoria\Diseño\Formatos Documentos - Final\1 LISTOS\FINAL\Pre\test\Reporte Diario\llenar_reporte_diario.py
import os
import zipfile
from io import BytesIO
import xml.etree.ElementTree as ET
from copy import deepcopy  # Necesario para modificar diccionarios de contexto
import re
from openpyxl import load_workbook
from openpyxl.utils import range_boundaries, get_column_letter
from openpyxl.utils.exceptions import InvalidFileException
import math
import random

# Espacio de nombres de Word para la búsqueda en el XML
NS_W = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

from datetime import datetime, timedelta

def _calculate_shift_hours(start_time_str, end_time_str):
    """
    Calcula la duración del turno en horas decimales (hh:mm -> float).
    Maneja turnos que cruzan la medianoche.
    Ejemplo: 21:00 a 09:00 = 12 horas.
    """
    try:
        # Parsear las horas (asumimos que están en el mismo día por defecto)
        start_time = datetime.strptime(start_time_str, '%H:%M')
        end_time = datetime.strptime(end_time_str, '%H:%M')

        # Si la hora de término es anterior a la de inicio, significa que cruza la medianoche
        if end_time < start_time:
            end_time += timedelta(days=1)

        duration = end_time - start_time
        # Convertir a horas decimales
        total_hours = duration.total_seconds() / 3600

        # Excel usa el formato de día fraccional, por lo que devolvemos horas/24
        # Pero, para el cálculo HH = Horas_Turno * Cantidad, necesitamos el número de horas entero
        return total_hours
        
    except ValueError as e:
        raise ValueError(f"Formato de hora inválido ('{start_time_str}' o '{end_time_str}'). Debe ser HH:MM. Error: {e}")

# --- Fin de la Función Auxiliar ---



def update_embedded_xlsx_names(xlsx_bytes, name_values):
    """
    Actualiza los valores de los nombres definidos de Excel.
    name_values es un diccionario {nombre: valor}
    """
    try:
        wb = load_workbook(BytesIO(xlsx_bytes), data_only=False)
    except InvalidFileException:
        return xlsx_bytes

    modified = False

    for name, name_obj in wb.defined_names.items():
        if name in name_values:
            # Obtener el primer destino (generador, así que usamos next())
            try:
                dest_sheet, dest_coord = next(name_obj.destinations)
            except StopIteration:
                # No hay destinos, saltar
                continue
            
            ws = wb[dest_sheet]
            cell_ref = dest_coord
            
            # Escribir el nuevo valor
            cell = ws[cell_ref]
            cell.value = name_values[name]
            cell.number_format = "[h]:mm"   # o "[h]:mm" si quieres más de 24h
            modified = True

    if modified:
        out = BytesIO()
        wb.save(out)
        return out.getvalue()

    return xlsx_bytes






def _shift_formula_rows(formula, src_row, dst_row):
    """
    Ajusta referencias A1 en fórmulas.
    Las referencias estructuradas de tabla ([[#This Row],...]) NO deben tocarse.
    """

    # Si es fórmula con referencias de tabla estructurada → NO TOCAR
    if '[#This Row]' in formula or '[[' in formula:
        return formula

    # --- Fórmulas normales A1 ---
    row_offset = dst_row - src_row

    pattern = re.compile(r'(\$?[A-Z]{1,3})(\d+)')

    def repl(match):
        col = match.group(1)
        row = int(match.group(2))
        new_row = row + row_offset
        return f"{col}{new_row}"

    return pattern.sub(repl, formula)



# --- Funciones Auxiliares ---


def _ref_to_bounds(ref):
    """Convierte un rango tipo 'A1:J10' a (min_col, min_row, max_col, max_row)."""
    return range_boundaries(ref)


def _get_table_headers(ws, ref):
    """Obtiene un diccionario de {nombre_columna: indice_columna} para una tabla."""
    min_col, min_row, max_col, max_row = _ref_to_bounds(ref)
    header_row = min_row
    headers = {}

    for col in range(min_col, max_col + 1):
        cell = ws.cell(row=header_row, column=col)
        if cell.value:
            headers[str(cell.value).strip()] = col

    return headers, min_row, max_row


def _is_hour_format_valid(value):
    try:
        f_val = float(value)
        return f_val >= 0 and f_val < 1
    except (ValueError, TypeError):
        return False


def _is_integer_valid(value):
    try:
        i_val = int(value)
        return i_val >= 0
    except (ValueError, TypeError):
        return False


# ============================================================
# 🔶 FUNCIÓN CRÍTICA: EXPANDIR TABLA EXCEL AUTOMÁTICAMENTE
# ============================================================


def ensure_table_min_rows(ws, tbl, required_rows):
    """
    Garantiza que la tabla Excel tenga al menos 'required_rows' filas de datos.
    Si no, inserta filas, actualiza tbl.ref y copia formato/fórmulas
    de la PRIMERA FILA DE DATOS de la tabla.
    """

    min_col, min_row, max_col, max_row = range_boundaries(tbl.ref)

    header_row = min_row
    first_data_row = header_row + 1  # primera fila de datos (debajo del header)

    # Filas de datos actuales (sin contar el header)
    current_rows = max_row - header_row
    missing = required_rows - current_rows

    if missing <= 0:
        return header_row, max_row

    # Insertar filas inmediatamente después de la última fila de la tabla
    insert_at = max_row + 1

    # 1) Insertar filas en la hoja
    ws.insert_rows(insert_at, missing)

    new_max_row = max_row + missing

    # 2) Copiar formato + fórmulas desde la primera fila de datos
    for col in range(min_col, max_col + 1):
        src_cell = ws.cell(row=first_data_row, column=col)

        for new_row in range(insert_at, new_max_row + 1):
            dst_cell = ws.cell(row=new_row, column=col)

            # Copiar estilo completo
            dst_cell._style = src_cell._style

            src_val = src_cell.value

            if isinstance(src_val, str) and src_val.startswith("="):
                # Fórmulas estructuradas: copiar literal, sin shift
                if '[#This Row]' in src_val or '[[' in src_val:
                    dst_cell.value = src_val
                else:
                    # Fórmulas A1 normales → shift
                    dst_cell.value = _shift_formula_rows(src_val, first_data_row, new_row)

            else:
                # Para celdas vacías o constantes → vaciar, porque update_data_rows las llenará
                dst_cell.value = None



    # 3) Actualizar la referencia de la tabla
    new_ref = (
        f"{get_column_letter(min_col)}{min_row}:"
        f"{get_column_letter(max_col)}{new_max_row}"
    )
    tbl.ref = new_ref

    return header_row, new_max_row


# -------------------------------------------------------------
# 1) RELLENAR CONTROLES DE CONTENIDO EN WORD POR TAG
# -------------------------------------------------------------


def fill_content_controls(document_xml_bytes, context):
    root = ET.fromstring(document_xml_bytes)

    for sdt in root.findall(".//w:sdt", NS_W):
        tag_elem = sdt.find("./w:sdtPr/w:tag", NS_W)
        if tag_elem is None:
            continue

        tag_val = tag_elem.get(f"{{{NS_W['w']}}}val")

        if (
            tag_val == "nombre_representante_reporte_diario"
            and "nombre_representante_metso_reporte_diario" in context
        ):
            tag_val = "nombre_representante_metso_reporte_diario"

        if not tag_val or tag_val not in context:
            continue

        new_text = str(context[tag_val])
        texts = sdt.findall(".//w:sdtContent//w:t", NS_W)

        if not texts:
            continue

        for t in texts:
            t.text = ""

        texts[0].text = new_text

    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


# ==================================================================
# 2) ACTUALIZAR TABLA 'avance_turno' (NO TOCAR LÓGICA)
# ==================================================================


def update_avance_turno_xlsx(xlsx_bytes, doc_index, total_docs, daily_plan, daily_real):

    col_name_plan = "% AVANCE DIARIO PLANIFICADO"
    col_name_real = "% AVANCE DIARIO REAL"
    col_name_acum_plan = "AVANCE PLANIFICADO (ACUMULADO)"
    col_name_acum_real = "AVANCE REAL (ACUMULADO)"
    col_name_n_reporte = "N° REPORTE DIARIO"

    try:
        wb = load_workbook(BytesIO(xlsx_bytes), data_only=False)
    except InvalidFileException:
        return xlsx_bytes

    found = False

    for ws in wb.worksheets:
        for tbl in ws._tables.values():

            if tbl.name != "avance_turno":
                continue

            found = True

            # Asegurar filas necesarias
            header_row, max_row = ensure_table_min_rows(ws, tbl, total_docs)

            ref = tbl.ref
            headers, header_row, max_row = _get_table_headers(ws, ref)
            total_rows = max_row - header_row

            col_map = {
                col_name_n_reporte: headers.get(col_name_n_reporte),
                col_name_plan: headers.get(col_name_plan),
                col_name_real: headers.get(col_name_real),
                col_name_acum_plan: headers.get(col_name_acum_plan),
                col_name_acum_real: headers.get(col_name_acum_real),
            }

            if not all(col_map.values()):
                return xlsx_bytes

            # LLENADO DE CURVA S FILA A FILA
            for i in range(1, total_rows + 1):
                excel_row = header_row + i

                if i <= doc_index:
                    # Rellenar con datos acumulados hasta el turno actual (doc_index)
                    p = float(daily_plan[i - 1])
                    r = float(daily_real[i - 1])

                    # Acumulados históricos
                    acum_p = sum(daily_plan[:i])
                    acum_r = sum(daily_real[:i])

                    # N° reporte diario y valores diarios
                    ws.cell(excel_row, col_map[col_name_n_reporte]).value = i
                    ws.cell(excel_row, col_map[col_name_plan]).value = p
                    ws.cell(excel_row, col_map[col_name_real]).value = r

                    # Última fila del último documento: forzar 100% en acumulados
                    if i == total_docs:
                        ws.cell(excel_row, col_map[col_name_acum_plan]).value = 1.0
                        ws.cell(excel_row, col_map[col_name_acum_real]).value = 1.0
                    else:
                        ws.cell(excel_row, col_map[col_name_acum_plan]).value = acum_p
                        ws.cell(excel_row, col_map[col_name_acum_real]).value = acum_r

                elif i <= total_docs:
                    # Fila futura (Turnos siguientes) → vacía
                    for col in col_map.values():
                        ws.cell(excel_row, col).value = None

                else:
                    # Filas extra (más allá del total de documentos) → limpiar
                    for col in col_map.values():
                        ws.cell(excel_row, col).value = None

    if not found:
        return xlsx_bytes

    out = BytesIO()
    wb.save(out)
    return out.getvalue()


# -------------------------------------------------------------
# 3) FUNCIÓN GENERAL PARA OTRAS TABLAS EMBEBIDAS
# -------------------------------------------------------------


def update_data_rows(ws, table_name, data_rows, header_row, max_row, headers):
    HOUR_COLS = ["H.M. ASIGN.", "H. M. OPER.", "H.M. S-BY", "H. INICIO", "H. FIN"]
    INT_COLS = ["CANT", "CANT. PLAN.", "CANT. REAL"]

    # Escribir filas de datos
    for idx, row_data in enumerate(data_rows):
        excel_row = header_row + idx + 1

        # Seguridad adicional (aunque ensure_table_min_rows ya extiende)
        if excel_row > max_row:
            continue

        for col_name, value in row_data.items():
            col_name_strip = str(col_name).strip()

            if col_name_strip not in headers:
                continue

            col = headers[col_name_strip]

            # --- VALIDACIÓN DE FORMATO ---
            if col_name_strip in HOUR_COLS:
                if not _is_hour_format_valid(value):
                    raise ValueError(
                        f"Tabla '{table_name}': '{col_name_strip}' fila {idx+1} debe "
                        f"ser float >=0 <1. Valor: {value}"
                    )

            if col_name_strip in INT_COLS:
                if not _is_integer_valid(value):
                    raise ValueError(
                        f"Tabla '{table_name}': '{col_name_strip}' fila {idx+1} debe "
                        f"ser entero >=0. Valor: {value}"
                    )

            # --- COLUMNAS QUE NO SE ESCRIBEN DESDE PYTHON (FORMULAS) ---
            if col_name_strip in [
                "HH PLAN.",
                "HH REAL",
                "H. TOTAL",
                "DISPONIBILIDAD",
                "UTILIZACIÓN",
                "USO EFECTIVO",
                "STAND-BY",
                # "R. CRÍT",  # 👈 YA NO SE IGNORA, SE ESCRIBE (Sí/No)
            ]:
                continue

            # Escribir el valor
            ws.cell(excel_row, col).value = value

    # Limpiar filas restantes si la tabla es más grande que los datos de entrada
    rows_to_clear_start = header_row + len(data_rows) + 1

    for row in range(rows_to_clear_start, max_row + 1):
        for col in headers.values():
            ws.cell(row=row, column=col).value = None  # Limpia el contenido de la celda


def update_embedded_xlsx_tables(xlsx_bytes, tables_context):
    try:
        wb = load_workbook(BytesIO(xlsx_bytes), data_only=False)
    except InvalidFileException:
        return xlsx_bytes

    modified = False

    for ws in wb.worksheets:
        for tbl in ws._tables.values():
            name = tbl.name

            if name not in tables_context:
                continue

            # Saltar 'avance_turno', que se maneja por separado
            if name == "avance_turno":
                continue

            modified = True
            rows = tables_context[name]
            required_rows = len(rows)

            try:
                # 1. Asegurar la cantidad mínima de filas (Expansión automática)
                if required_rows > 0:
                    ensure_table_min_rows(ws, tbl, required_rows)

                # 2. Obtener los headers y los límites actualizados
                ref = tbl.ref
                headers, header_row, max_row = _get_table_headers(ws, ref)

                # 3. Llenar los datos y limpiar el exceso
                update_data_rows(ws, name, rows, header_row, max_row, headers)

            except ValueError as e:
                # Captura y relanza errores de validación (float < 1, entero >= 0)
                raise e
            except Exception as e:
                print(f"Error procesando tabla '{name}': {e}")

    if modified:
        out = BytesIO()
        wb.save(out)
        return out.getvalue()

    return xlsx_bytes


# -------------------------------------------------------------
# 4) GENERAR N DOCUMENTOS
# -------------------------------------------------------------


def generate_reports(
    template_path, output_dir, docs_context, daily_plan, daily_real, base_name="REPORTE"
):

    os.makedirs(output_dir, exist_ok=True)

    total_docs = len(docs_context)

    if len(daily_plan) != total_docs or len(daily_real) != total_docs:
        raise ValueError("daily_plan y daily_real deben tener largo = N")

    if abs(sum(daily_plan) - 1.0) > 1e-6:
        raise ValueError("La suma de daily_plan debe ser 1.0")

    if abs(sum(daily_real) - 1.0) > 1e-6:
        raise ValueError("La suma de daily_real debe ser 1.0")

    print(f"Iniciando generación de {total_docs} reportes en '{output_dir}/'")

    with open(template_path, "rb") as f:
        template_bytes = f.read()

    for i, context in enumerate(docs_context, start=1):
        out_path = os.path.join(output_dir, f"{base_name}_{i:02d}.docx")

        cc_context = {k: v for k, v in context.items() if k != "excel_tables"}
        tables_ctx = context.get("excel_tables", {})

        with zipfile.ZipFile(BytesIO(template_bytes), "r") as zin:
            with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = zin.read(item.filename)

                    if item.filename == "word/document.xml":
                        data = fill_content_controls(data, cc_context)

                    elif item.filename.startswith(
                        "word/embeddings/"
                    ) and item.filename.endswith(".xlsx"):

                        # -----------------------------------------------------
                        # 1. PREPARAR NOMBRES DEFINIDOS (HH_TURNO)
                        # -----------------------------------------------------
                        # Calcular horas totales del turno (ej: 12.0 horas)
                        # NOTA: _calculate_shift_hours debe estar definida en el código.
                        hh_turno = _calculate_shift_hours(
                            cc_context["hora_inicio"], cc_context["hora_termino"]
                        )
                        
                        # Insertar valor numérico en horas
                        name_updates = {
                            "hh_turno_directo": hh_turno / 24,
                            "hh_turno_indirecto": hh_turno / 24,
                        }
                        # Actualizar los Nombres Definidos en el XLSX
                        # NOTA: update_embedded_xlsx_names debe estar definida en el código.
                        data = update_embedded_xlsx_names(data, name_updates)

                        # -----------------------------------------------------
                        # 2. Actualizar Avance de Turno (Curva S)
                        # -----------------------------------------------------
                        data = update_avance_turno_xlsx(
                            data,
                            doc_index=i,
                            total_docs=total_docs,
                            daily_plan=daily_plan,
                            daily_real=daily_real,
                        )

                        # -----------------------------------------------------
                        # 3. Actualizar otras tablas (Personal, Equipos, etc.)
                        # -----------------------------------------------------
                        data = update_embedded_xlsx_tables(data, tables_ctx)

                    zout.writestr(item, data)

        print(f"✔ Generado: {out_path}")

    print("\nProceso completado.")


# -------------------------------------------------------------
# 4B) CURVA S CLÁSICA (NO TOCAR LA LÓGICA)
# -------------------------------------------------------------


def generar_curvas_s_clasica(N, ruido_real=0.10):
    """
    Genera daily_plan y daily_real con forma de curva S (sigmoidal).
    - daily_plan: suave, simétrica, suma 1.0
    - daily_real: daily_plan + ruido, normalizado a 1.0
    """

    # --------------- 1) Calcular puntos sigmoides acumulados ----------------
    # Curva sigmoide clásica centrada en N/2
    # Fórmula: S(x) = 1 / (1 + e^(-(x-k)/a))
    k = N / 2
    a = N / 10  # qué tan "ancha" es la S

    S = [1 / (1 + math.exp(-(i - k) / a)) for i in range(N + 1)]

    # Normalizar S a 0 → 1 (asegura acumulado correcto)
    S_min = S[0]
    S_max = S[-1]
    S = [(x - S_min) / (S_max - S_min) for x in S]

    # ---------------- 2) Derivar para obtener daily_plan --------------------
    daily_plan = [S[i] - S[i - 1] for i in range(1, N + 1)]

    # Normalizar para corregir redondeos
    total = sum(daily_plan)
    daily_plan = [x / total for x in daily_plan]

    # ---------------- 3) daily_real = daily_plan + ruido -------------------
    daily_real = []
    for p in daily_plan:
        delta = random.uniform(-ruido_real, ruido_real)
        daily_real.append(max(0.0, p + delta))

    # Normalizar daily_real
    total_r = sum(daily_real)
    daily_real = [r / total_r for r in daily_real]

    return daily_plan, daily_real


# -------------------------------------------------------------
# 5) EJEMPLO DE USO CON DATOS DINÁMICOS
# -------------------------------------------------------------
if __name__ == "__main__":

    TEMPLATE = "REPORTE.docx"
    OUTPUT_DIR = "salida_reportes_completo"
    N = 3  # Total de turnos/documentos

    # Curva S (NO TOCAR)
    daily_plan, daily_real = generar_curvas_s_clasica(N)

    docs_context = []

    # Lista de turnos variados (hora_inicio, hora_termino)
    shifts = [
        ("07:00", "19:00"),
        ("08:00", "20:00"),
        ("06:30", "18:30"),
        ("21:00", "09:00"),
        ("22:00", "10:00"),
        ("20:30", "08:30"),
        ("07:30", "19:30"),
    ]

    # Lista de referencias y ubicaciones variadas (equipos/máquinas y faenas)
    referencias_ubicaciones = [
        ("CH-001", "CHANCADORA PRIMARIA - ZONA NORTE"),
        ("CH-002", "CHANCADORA SECUNDARIA - ZONA SUR"),
        ("SG-001", "MOLINO SAG - ZONA ESTE"),
    ]

    # ----------------------------------------------------------
    # 🔧 GENERADOR DE PERSONAL DIRECTO
    # ----------------------------------------------------------
    def generar_personal_directo(turno):
        base = [
            ("Supervisor Mecánico", 1),
            ("Técnico Mecánico", 4),
            ("Soldador Especialista", 2),
            ("Ayudante Mecánico", 3),
            ("Lubricador", 1),
            ("Técnico Hidráulico", 1),
        ]

        personal = []
        for cargo, base_cant in base:
            variacion = random.choice([-1, 0, 1])
            cant_plan = max(1, base_cant + variacion)
            cant_real = max(0, cant_plan + random.choice([-1, 0, 1]))

            personal.append(
                {
                    "CANT": cant_plan,
                    "CARGO": cargo,
                    "CANT. PLAN.": cant_plan,
                    "CANT. REAL": cant_real,
                }
            )

        return personal

    # ----------------------------------------------------------
    # 🔧 PERSONAL INDIRECTO DINÁMICO
    # ----------------------------------------------------------
    def generar_personal_indirecto(turno):
        cargos = [
            "HSE",
            "Bodeguero",
            "Planificador",
            "Ingeniero de Proyecto",
            "Administrador de Contrato",
        ]

        personal = []
        for cargo in cargos:
            cant_plan = 1
            cant_real = 1 if random.random() > 0.2 else 0
            personal.append(
                {
                    "CANT": cant_plan,
                    "CARGO": cargo,
                    "CANT. PLAN.": cant_plan,
                    "CANT. REAL": cant_real,
                }
            )
        return personal

    # ----------------------------------------------------------
    # 🔧 EQUIPOS AUXILIARES DINÁMICOS
    # ----------------------------------------------------------
    def generar_equipos_auxiliares(turno):
        equipos = [
            ("Camión Pluma", 0.45, 0.50),
            ("Camioneta", 0.50, 0.50),
            ("Grúa Horquilla", 0.40, 0.48),
            ("Plataforma Elevadora", 0.35, 0.45),
            ("Compresor", 0.50, 0.50),
            ("Torre de Iluminación", 0.45, 0.50),
        ]

        motivos = [
            "Condición de terreno",
            "Esperando instrucciones",
            "Clima adverso",
            "Interferencia de otros equipos",
            "Falta de operador",
        ]

        lista = []
        for nombre, min_op, max_op in equipos:
            asign = 0.50
            oper = round(random.uniform(min_op, max_op), 3)
            # Asegurar que standby nunca sea negativo
            standby = round(max(0.0, asign - oper), 3)

            if standby > 0:
                motivo = random.choice(motivos)
            else:
                motivo = ""

            lista.append(
                {
                    "CANT": random.choice([1, 1, 2]),
                    "DESCRIPCIÓN": nombre,
                    "H.M. ASIGN.": asign,
                    "H. M. OPER.": oper,
                    "H.M. S-BY": standby,
                    "OBS. / MOTIVO STAND-BY": motivo,
                }
            )
        return lista

    # ----------------------------------------------------------
    # 🔧 DESVIACIONES DINÁMICAS
    # ----------------------------------------------------------
    def generar_desviaciones(turno):
        desc = [
            "Problema con perno",
            "Falla de energía",
            "Interferencia de contratistas",
            "Bloqueo de acceso",
            "Retraso en repuestos",
            "Condiciones climáticas adversas",
        ]

        n = random.randint(1, 4)
        items = random.sample(desc, n)
        lista = []
        for idx, d in enumerate(items, start=1):
            inicio = random.uniform(0.05, 0.25)
            fin = inicio + random.uniform(0.03, 0.15)
            lista.append(
                {
                    "N": idx,
                    "DESCRIPCIÓN": d,
                    "H. INICIO": round(inicio, 5),
                    "H. FIN": round(fin, 5),
                    # Data validation en Excel: lista "Sí;No"
                    "R. CRÍT": "Sí" if random.random() > 0.7 else "No",
                }
            )
        return lista

    # ----------------------------------------------------------
    # 🔧 ACTIVIDADES REALIZADAS DINÁMICAS
    # ----------------------------------------------------------
    def generar_actividades(turno):
        base = [
            "Izaje y retiro de pieza",
            "Revisión estructural",
            "Ajuste de pernos",
            "Lubricación de componentes",
            "Limpieza y orden",
            "Chequeo de torque",
        ]
        random.shuffle(base)
        acts = base[: random.randint(3, 6)]
        return [{"N": i + 1, "DESCRIPCIÓN": a} for i, a in enumerate(acts)]

    # ----------------------------------------------------------
    # 🔧 HALLAZGOS DINÁMICOS
    # ----------------------------------------------------------
    def generar_hallazgos(turno):
        base = [
            "Uso incorrecto de EPP",
            "Objetos en pasillos",
            "Trabajador sin amarre",
            "Procedimiento no seguido",
            "Zona sin demarcar",
        ]
        n = random.randint(0, 3)
        items = random.sample(base, n)
        return [{"N": i + 1, "DESCRIPCIÓN": x} for i, x in enumerate(items)]

    # ----------------------------------------------------------
    # 🔧 HITOS DEL TURNO DINÁMICOS
    # ----------------------------------------------------------
    def generar_hitos(turno):
        base = [
            "Montaje de equipo crítico",
            "Entrega parcial de repuestos",
            "Validación metrológica",
            "Cierre de inspección",
        ]
        items = random.sample(base, random.randint(1, 3))
        return [{"N": i + 1, "DESCRIPCIÓN": a} for i, a in enumerate(items)]

    # ----------------------------------------------------------
    # 🔥 LOOP PRINCIPAL DE DOCUMENTOS
    # ----------------------------------------------------------
    for i in range(1, N + 1):
        start, end = random.choice(shifts)
        jornada = "Día" if int(start.split(":")[0]) < 12 else "Noche"
        
        # Seleccionar aleatoriamente referencia y ubicación
        ref, ubic = random.choice(referencias_ubicaciones)

        context = {
            "nombre_proyecto": "OVERHAUL CHANCADORA X",
            "referencia_turno": ref,  # Código de identificación del equipo/máquina
            "fecha_turno": f"2025-01-0{i}",
            "ubicacion_turno": ubic,  # Ubicación variable según el equipo
            "num_reporte_diario": str(i),
            "tipo_jornada": jornada,
            "hora_inicio": start,
            "hora_termino": end,
            "nombre_representante_metso_reporte_diario": f"Metso Rep {i}",
            "nombre_representante_cliente_reporte_diario": f"Cliente Rep {i}",
            "excel_tables": {
                "personal_directo": generar_personal_directo(i),
                "personal_indirecto": generar_personal_indirecto(i),
                "equipos_auxiliares": generar_equipos_auxiliares(i),
                "desviaciones_turno": generar_desviaciones(i),
                "act_realizadas": generar_actividades(i),
                "hallazgos_seguridad": generar_hallazgos(i),
                "hitos_relevantes_turno": generar_hitos(i),
            },
        }

        docs_context.append(context)

    # ----------------------------------------------------------
    # 🔥 EJECUTAR GENERADOR
    # ----------------------------------------------------------
    try:
        generate_reports(
            TEMPLATE,
            OUTPUT_DIR,
            docs_context,
            daily_plan,
            daily_real,
        )
    except Exception as e:
        print("\n❌ ERROR:", e)


