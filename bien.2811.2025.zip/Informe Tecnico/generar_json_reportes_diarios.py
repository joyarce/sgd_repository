# coding: utf-8
"""
extraer_reportes_a_json.py – versión corregida FINAL + hh_turno
"""

import os
import zipfile
import json
from io import BytesIO
import xml.etree.ElementTree as ET
from openpyxl import load_workbook
from openpyxl.utils import range_boundaries

# Namespace Word
NS_W = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

import datetime


# =====================================================================
# CONVERSIÓN UNIVERSAL A FORMATO JSON SEGURO
# =====================================================================
def make_json_safe(value):
    if isinstance(value, datetime.time):
        return value.strftime("%H:%M:%S")

    if isinstance(value, datetime.datetime):
        return value.time().strftime("%H:%M:%S")

    if isinstance(value, datetime.timedelta):
        total_seconds = int(value.total_seconds())
        h = total_seconds // 3600
        m = (total_seconds % 3600) // 60
        s = total_seconds % 60
        return f"{h:02d}:{m:02d}:{s:02d}"

    if isinstance(value, (int, float)):
        total_seconds = int(round(value * 24 * 3600))
        h = total_seconds // 3600
        m = (total_seconds % 3600) // 60
        s = total_seconds % 60
        return f"{h:02d}:{m:02d}:{s:02d}"

    if isinstance(value, str):
        if "." in value and ":" in value:
            try:
                t = datetime.datetime.strptime(value, "%H:%M:%S.%f")
                return t.strftime("%H:%M:%S")
            except:
                pass

        try:
            t = datetime.datetime.strptime(value, "%H:%M:%S")
            return t.strftime("%H:%M:%S")
        except:
            pass

        return value

    if isinstance(value, bytes):
        return value.decode("utf-8", errors="ignore")

    return str(value)


# ---------------------------------------------------------
# EXTRAER CONTROLES DE CONTENIDO (SDT)
# ---------------------------------------------------------
def extract_content_controls(document_xml_bytes):
    root = ET.fromstring(document_xml_bytes)
    datos = {}

    for sdt in root.findall(".//w:sdt", NS_W):
        tag_elem = sdt.find("./w:sdtPr/w:tag", NS_W)
        if tag_elem is None:
            continue

        tag_val = tag_elem.get(f"{{{NS_W['w']}}}val")
        if not tag_val:
            continue

        textos = sdt.findall(".//w:sdtContent//w:t", NS_W)
        full_text = "".join([t.text or "" for t in textos]).strip()

        datos[tag_val] = make_json_safe(full_text)

    return datos


# ---------------------------------------------------------
# EXTRAER NOMBRES DEFINIDOS DE EXCEL (Named Ranges)
# ---------------------------------------------------------
def extract_excel_names(wb):
    result = {}

    # wb.defined_names es un dict: {name: DefinedName}
    for name_str, defn in wb.defined_names.items():

        try:
            destinations = list(defn.destinations)
        except:
            continue

        for sheet_name, cell_ref in destinations:
            try:
                ws = wb[sheet_name]
                cell = ws[cell_ref]
                result[name_str] = make_json_safe(cell.value)
            except:
                pass  # ignorar celdas o nombres inválidos

    return result




# ---------------------------------------------------------
# EXTRAER TABLAS DESDE UN EXCEL EMBEBIDO
# ---------------------------------------------------------
def extract_excel_tables(xlsx_bytes):
    try:
        wb = load_workbook(BytesIO(xlsx_bytes), data_only=False)
    except:
        return {}, {}

    tables_out = {}

    # Extraer tablas
    for ws in wb.worksheets:
        for tbl in ws._tables.values():
            tbl_name = tbl.name
            min_col, min_row, max_col, max_row = range_boundaries(tbl.ref)

            headers = []
            for c in range(min_col, max_col + 1):
                val = ws.cell(row=min_row, column=c).value
                headers.append("" if val is None else str(val).strip())

            rows = []
            for r in range(min_row + 1, max_row + 1):
                row_data = {}
                for idx, c in enumerate(range(min_col, max_col + 1)):
                    header = headers[idx]
                    val = ws.cell(row=r, column=c).value
                    row_data[header] = make_json_safe(val)
                rows.append(row_data)

            tables_out[tbl_name] = {"headers": headers, "rows": rows}

    # Extraer named ranges
    names_out = extract_excel_names(wb)

    return tables_out, names_out


# ---------------------------------------------------------
# PROCESAR UN ARCHIVO .DOCX COMPLETO
# ---------------------------------------------------------
def process_docx(path):
    print(f"Procesando {os.path.basename(path)} ...")

    with zipfile.ZipFile(path, "r") as z:
        data_doc = {}

        # 1. Controles SDT
        if "word/document.xml" in z.namelist():
            xml_doc = z.read("word/document.xml")
            data_doc["content_controls"] = extract_content_controls(xml_doc)
        else:
            data_doc["content_controls"] = {}

        # 2. Tablas Excel + named ranges
        tablas = {}
        nombres_excel = {}

        for item in z.namelist():
            if item.startswith("word/embeddings/") and item.endswith(".xlsx"):
                xlsx_bytes = z.read(item)
                tbls, names = extract_excel_tables(xlsx_bytes)
                tablas.update(tbls)
                nombres_excel.update(names)

        data_doc["excel_tables"] = tablas
        data_doc["excel_names"] = nombres_excel

        # 3. Calcular hh_turno
        hh1 = nombres_excel.get("hh_turno_directo")
        hh2 = nombres_excel.get("hh_turno_indirecto")

        if hh1 and hh2 and hh1 != hh2:
            print(f"⚠ Advertencia: hh_turno_directo != hh_turno_indirecto en {path}")

        data_doc["hh_turno"] = hh1 or hh2 or None

    return data_doc


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
def main(folder, output_file):
    documentos = []

    files = sorted(os.listdir(folder))

    for f in files:
        if f.lower().startswith("reporte_") and f.lower().endswith(".docx"):
            full_path = os.path.join(folder, f)
            info = process_docx(full_path)
            info["filename"] = f
            documentos.append(info)

    with open(output_file, "w", encoding="utf-8") as j:
        json.dump(documentos, j, indent=4, ensure_ascii=False)

    print("\n✔ JSON generado correctamente:")
    print(output_file)


# ---------------------------------------------------------
# CLI
# ---------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Extraer datos de reportes diarios .docx")
    parser.add_argument("--dir", required=True)
    parser.add_argument("--out", default="reporte_consolidado.json")
    args = parser.parse_args()

    main(args.dir, args.out)
