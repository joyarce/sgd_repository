# ============================================================
# llenar_informe_tecnico.py
# Rellena la plantilla INFORME TECNICO.docx con el JSON de turnos
# ============================================================

import json
import argparse
from docx import Document


# ------------------------------------------------------------
# UTILIDAD: RELLENAR CONTENROLES DE CONTENIDO (TAG <w:tag>)
# ------------------------------------------------------------
def fill_content_controls(doc, replacements):
    """
    Reemplaza texto de controles de contenido (CC) basados en sus tags.
    """
    from docx.oxml.ns import qn

    for sdt in doc.element.body.iter(qn('w:sdt')):
        # tag
        tag_elem = sdt.find('.//w:tag', docx_ns())
        if tag_elem is None:
            continue

        tag_val = tag_elem.get(qn('w:val'))
        if not tag_val:
            continue

        if tag_val not in replacements:
            continue

        # contenido
        texts = sdt.findall('.//w:t', docx_ns())
        for t in texts:
            t.text = replacements[tag_val]


def docx_ns():
    return {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


# ------------------------------------------------------------
# UTILIDAD: INSERTAR FILAS EN TABLA WORD
# ------------------------------------------------------------
def append_table_row(table, values):
    """
    Inserta una nueva fila al final de una tabla de Word.
    values = lista de strings
    """
    row = table.add_row()
    for idx, val in enumerate(values):
        row.cells[idx].text = "" if val is None else str(val)


# ------------------------------------------------------------
# EXTRAER TABLA WORD POR SU ENCABEZADO
# ------------------------------------------------------------
def find_table_by_header(doc, header_row_text):
    """
    Busca una tabla cuyo primer row (concatenado) coincide con header_row_text.
    header_row_text = "ID|Fecha|Inicio|Fin|Hr|R. Crítica|Resp.|Tipo|Descripción"
    """
    header_row_text = header_row_text.replace(" ", "").lower()

    for table in doc.tables:
        first_row = table.rows[0].cells
        row_join = "|".join(c.text.replace(" ", "").lower() for c in first_row)
        if row_join == header_row_text:
            return table
    return None


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
def main(json_file, template_path, output_path):

    print("\n=== Cargando JSON de turnos ===")
    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    print("JSON OK. Turnos cargados:", len(data))

    print("\n=== Cargando plantilla Informe Técnico ===")
    doc = Document(template_path)

    # --------------------------------------------------------
    # 1. RELLENO DE CONTROLES CC
    # --------------------------------------------------------
    print("\nRellenando controles de contenido...")

    primer = data[0]["content_controls"]
    ultimo = data[-1]["content_controls"]

    replacements = {
        "nombre_proyecto": primer.get("nombre_proyecto", ""),
        "fecha_inicio_ejecucion": primer.get("fecha_turno", ""),
        "fecha_cierre_proyecto": ultimo.get("fecha_turno", ""),
        #
        # Puedes agregar todas las claves CC adicionales aquí
        #
    }

    fill_content_controls(doc, replacements)

    # --------------------------------------------------------
    # 2. TABLA: REGISTRO DE DESVIACIONES
    # --------------------------------------------------------
    print("\nInsertando desviaciones...")

    header_desv = "ID|Fecha|Inicio|Fin|Hr|R.Crítica|Resp.|Tipo|Descripción"
    tbl_desv = find_table_by_header(doc, header_desv)

    if tbl_desv is None:
        print("ERROR: No se encontró tabla de desviaciones en la plantilla.")
        return

    id_counter = 1

    for reporte in data:
        fecha = reporte["content_controls"]["fecha_turno"]
        desv = reporte["excel_tables"].get("desviaciones_turno", {})

        for row in desv.get("rows", []):
            append_table_row(tbl_desv, [
                id_counter,
                fecha,
                row.get("H. INICIO", ""),
                row.get("H. FIN", ""),
                row.get("H. TOTAL", ""),
                row.get("R. CRÍT", ""),
                "",      # Responsable -> la plantilla lo exige pero NO viene en reportes
                "",      # Tipo -> definido en CC pero no existe en reportes
                row.get("DESCRIPCIÓN", "")
            ])
            id_counter += 1

    # --------------------------------------------------------
    # 3. TABLA: ACTIVIDADES EJECUTADAS
    # --------------------------------------------------------
    print("\nInsertando actividades ejecutadas...")

    header_acts = "fecha_turno|tipo_jornada.|actividad_turno_tipo_jornada."
    tbl_acts = find_table_by_header(doc, header_acts)

    if tbl_acts is None:
        print("ERROR: No se encontró tabla ACTIVIDADES EJECUTADAS.")
        return

    for reporte in data:
        fecha = reporte["content_controls"]["fecha_turno"]
        jornada = reporte["content_controls"]["tipo_jornada"]
        acts = reporte["excel_tables"].get("act_realizadas", {}).get("rows", [])

        for act in acts:
            append_table_row(tbl_acts, [
                fecha,
                jornada,
                act.get("DESCRIPCIÓN", "")
            ])

    # --------------------------------------------------------
    # GUARDAR DOCUMENTO FINAL
    # --------------------------------------------------------
    doc.save(output_path)
    print("\n✔ INFORME TÉCNICO generado correctamente:")
    print(output_path)


# ------------------------------------------------------------
# CLI
# ------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generar Informe Tecnico desde JSON consolidado.")
    parser.add_argument("--json", required=True)
    parser.add_argument("--template", required=True)
    parser.add_argument("--out", default="INFORME_TECNICO_COMPLETO.docx")

    args = parser.parse_args()

    main(args.json, args.template, args.out)
